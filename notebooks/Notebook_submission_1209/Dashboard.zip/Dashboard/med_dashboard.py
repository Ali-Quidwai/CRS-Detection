import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from dotenv import load_dotenv
import os
import asyncio
import aiohttp
from concurrent.futures import ThreadPoolExecutor
import plotly.io as pio

# Load environment variables
load_dotenv()
anthropic_api_key = os.getenv("ANTHROPIC_API_KEY")

st.set_page_config(page_title="Patient Journey Dashboard", page_icon="📊", layout="wide")

st.markdown("""
    <style>
    .block-container {
        padding-top: 2rem;
        padding-bottom: 1rem;
    }
    footer {visibility: hidden;}
    .css-1d391kg {width: 300px;}
    .main > div:first-child {
        margin-bottom: 1rem;
    }
    table {
        font-size: 14px;
    }
    .main > div > h2 {
        margin-top: 1.5rem;
    }
    </style>
""", unsafe_allow_html=True)

st.title("Patient Journey Dashboard")
st.write("Explore patient data and visualize variables over time (using datetime), correlate them, and analyze distributions. Use the sidebar to customize.")

@st.cache_data
def load_data(file_path):
    df = pd.read_csv(file_path, low_memory=False)
    if "Unnamed: 0" in df.columns:
        df = df.drop(columns=["Unnamed: 0"])
    if 'datetime' in df.columns:
        df['datetime'] = pd.to_datetime(df['datetime'], errors='coerce')
    else:
        st.warning("No 'datetime' column found in the CSV. Please ensure your data has a 'datetime' column.")
    return df

data = load_data("final_data_clipped.csv")

# Sidebar - Filters & Controls
st.sidebar.title("Filters & Controls")

compare_mode = st.sidebar.radio(
    "Select Comparison Mode:",
    ["Compare Multiple Variables per Patient", "Compare One Variable Across Patients"]
)

st.sidebar.subheader("Patient Selection")
patient_ids = data['patient_id'].unique()
select_all_patients = st.sidebar.checkbox("Select All Patients")
if select_all_patients:
    selected_patients = st.sidebar.multiselect("Select Patient IDs:", patient_ids, default=list(patient_ids))
else:
    selected_patients = st.sidebar.multiselect("Select Patient IDs:", patient_ids)

numeric_columns = data.select_dtypes(include=['number']).columns.tolist()
if 'patient_id' in numeric_columns:
    numeric_columns.remove('patient_id')

st.sidebar.subheader("Variable Selection")
if compare_mode == "Compare Multiple Variables per Patient":
    select_all_variables = st.sidebar.checkbox("Select All Variables")
    if select_all_variables:
        selected_variables = st.sidebar.multiselect("Select Variables to Compare:", numeric_columns, default=numeric_columns)
    else:
        selected_variables = st.sidebar.multiselect("Select Variables to Compare:", numeric_columns)
else:
    selected_variable = st.sidebar.selectbox("Select One Variable to Compare Across Patients", numeric_columns)
    selected_variables = [selected_variable] if selected_variable else []

st.sidebar.subheader("Data Range Filter")
min_index = int(data.index.min())
max_index = int(data.index.max())
index_range = st.sidebar.slider("Filter by Data Index Range:", min_value=min_index, max_value=max_index, value=(min_index, max_index))

st.sidebar.subheader("Plot Customization")
plot_type = st.sidebar.selectbox("Select Plot Type", ["line", "scatter", "bar"])
plot_theme = st.sidebar.selectbox("Select Plot Theme", ["plotly", "plotly_white", "plotly_dark", "ggplot2", "seaborn"])
pio.templates.default = plot_theme

rolling_window = st.sidebar.slider("Rolling Window for Smoothing (0 = off)", min_value=0, max_value=50, value=0, step=1)
st.sidebar.caption("Apply a rolling mean to smooth out the data.")

st.sidebar.subheader("Distribution Analysis")
show_distribution = st.sidebar.checkbox("Show Distribution of Selected Variable(s)")
dist_plot_type = st.sidebar.selectbox("Distribution Plot Type", ["Histogram", "Density"]) if show_distribution else None

st.sidebar.subheader("Analyze Patient Data with Claude")
user_prompt = st.sidebar.text_area("Enter your analysis request for Claude:", "Analyze patient data for trends")

async def fetch_claude_response(prompt, api_key):
    url = "https://api.anthropic.com/v1/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": "claude-2",
        "prompt": prompt,
        "max_tokens_to_sample": 1000,
    }
    async with aiohttp.ClientSession() as session:
        async with session.post(url, json=payload, headers=headers) as response:
            return await response.json()

if st.sidebar.button("Analyze with Claude"):
    with st.spinner("Analyzing with Claude..."):
        prompt = f"\n\nHuman: {user_prompt}\n\nAssistant:"
        result = asyncio.run(fetch_claude_response(prompt, anthropic_api_key))
    st.subheader("Claude Analysis Result")
    st.write(result.get("completion", "No response"))

@st.cache_data
def filter_data(data, selected_patients, selected_variables, index_range):
    df = data[data['patient_id'].isin(selected_patients)][['patient_id', 'datetime'] + selected_variables]
    df = df.loc[index_range[0]:index_range[1]]
    return df

filtered_data = filter_data(data, selected_patients, selected_variables, index_range)

if rolling_window > 0 and not filtered_data.empty:
    for var in selected_variables:
        if var in filtered_data.columns and pd.api.types.is_numeric_dtype(filtered_data[var]):
            filtered_data[var] = filtered_data[var].rolling(rolling_window, min_periods=1).mean()

st.header("Data Insights")
if not filtered_data.empty and 'datetime' in filtered_data.columns and not filtered_data['datetime'].isnull().all() and selected_patients and selected_variables:
    col1, col2 = st.columns([2,2])
    with col1:
        st.markdown("**Summary Statistics**")
        st.write(filtered_data.describe())
    with col2:
        if len(selected_variables) > 1:
            st.markdown("**Correlation Heatmap**")
            corr_df = filtered_data[selected_variables].corr()
            fig_corr = px.imshow(corr_df, 
                                 text_auto=True, 
                                 aspect="auto", 
                                 color_continuous_scale="RdBu_r", 
                                 title="Correlation Between Selected Variables",
                                 zmin=-1, zmax=1)
            fig_corr.update_xaxes(side="bottom")
            st.plotly_chart(fig_corr, use_container_width=True)
        else:
            st.info("Select more than one variable to see a correlation heatmap.")
else:
    st.info("No data selected or no datetime column available. Please check your selections and ensure that 'datetime' column exists and is valid.")

if show_distribution and not filtered_data.empty and selected_variables:
    st.header("Distribution of Selected Variables")
    color_sequence = px.colors.qualitative.Set2
    if compare_mode == "Compare Multiple Variables per Patient":
        for var in selected_variables:
            title_text = f"Distribution of {var}"
            if dist_plot_type == "Histogram":
                fig_dist = px.histogram(filtered_data, x=var, color="patient_id", marginal="box", nbins=30, title=title_text, color_discrete_sequence=color_sequence)
            else:
                fig_dist = px.histogram(filtered_data, x=var, color="patient_id", nbins=30, histnorm='probability density', marginal="box", opacity=0.5, title=title_text, color_discrete_sequence=color_sequence)
            fig_dist.update_layout(barmode='overlay', xaxis_title="Measurement Value", yaxis_title="Count/Density")
            st.plotly_chart(fig_dist, use_container_width=True)
    else:
        var = selected_variables[0]
        title_text = f"Distribution of {var} Across Patients"
        if dist_plot_type == "Histogram":
            fig_dist = px.histogram(filtered_data, x=var, color="patient_id", marginal="box", nbins=30, title=title_text, color_discrete_sequence=color_sequence)
        else:
            fig_dist = px.histogram(filtered_data, x=var, color="patient_id", nbins=30, histnorm='probability density', marginal="box", opacity=0.5, title=title_text, color_discrete_sequence=color_sequence)
        fig_dist.update_layout(barmode='overlay', xaxis_title="Measurement Value", yaxis_title="Count/Density")
        st.plotly_chart(fig_dist, use_container_width=True)

st.header("Variable Comparison")

def add_crs_annotations_and_points(fig, patient_data):
    crs_col = 'CRS on date (0 No, 1 Yes)'
    if crs_col in patient_data.columns:
        # Add points where CRS == 1 in red
        crs_data = patient_data[['datetime', crs_col]].copy()
        ones = crs_data[crs_data[crs_col] == 1]
        if not ones.empty:
            fig.add_trace(go.Scatter(
                x=ones['datetime'],
                y=ones[crs_col],
                mode='markers',
                marker=dict(color='red', size=8),
                name='CRS=1 Points'
            ))
        # Identify transitions
        crs_data['CRS_change'] = crs_data[crs_col].diff()
        transitions = crs_data[crs_data['CRS_change'].abs() == 1]
        for _, row in transitions.iterrows():
            dt_str = row['datetime'].strftime('%Y-%m-%d %H:%M:%S')
            if row['CRS_change'] == 1:
                # 0 -> 1 transition
                annotation_text = f"Patient has CRS on {dt_str}"
            else:
                # 1 -> 0 transition
                annotation_text = f"Patient has no CRS on {dt_str}"

            fig.add_annotation(
                x=row['datetime'],
                y=row[crs_col],
                text=annotation_text,
                showarrow=True,
                arrowhead=2,
                ax=20,
                ay=-30
            )

def generate_plot_multiple_vars_one_patient(patient_id):
    patient_data = filtered_data[filtered_data['patient_id'] == patient_id]

    if 'datetime' not in patient_data.columns or patient_data['datetime'].isnull().all() or patient_data.empty or not selected_variables:
        return None

    color_sequence = px.colors.qualitative.Set2
    if plot_type == "line":
        fig = px.line(
            patient_data,
            x='datetime',
            y=selected_variables,
            title=f"Variables Over Time for Patient ID {patient_id}",
            color_discrete_sequence=color_sequence
        )
    elif plot_type == "scatter":
        fig = px.scatter(
            patient_data,
            x='datetime',
            y=selected_variables,
            title=f"Variables Over Time for Patient ID {patient_id}",
            color_discrete_sequence=color_sequence
        )
    else:  # bar plot
        if len(selected_variables) == 1:
            fig = px.bar(
                patient_data,
                x='datetime',
                y=selected_variables[0],
                title=f"{selected_variables[0]} Over Time for Patient ID {patient_id}",
                color_discrete_sequence=color_sequence
            )
        else:
            long_df = patient_data.melt(id_vars=['patient_id','datetime'], value_vars=selected_variables, var_name='variable', value_name='value')
            fig = px.bar(
                long_df,
                x='datetime',
                y='value',
                color='variable',
                title=f"Variables Over Time for Patient ID {patient_id} (Stacked)",
                color_discrete_sequence=color_sequence
            )

    fig.update_layout(
        margin=dict(l=40, r=40, t=80, b=40),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        title={"x": 0.5, "y": 0.95, "xanchor": "center", "yanchor": "top", "font": {"size": 20}}
    )
    fig.update_xaxes(title="Date/Time")
    fig.update_yaxes(title="Measurement Value")

    if 'CRS on date (0 No, 1 Yes)' in selected_variables:
        add_crs_annotations_and_points(fig, patient_data)

    return fig

def generate_plot_one_var_multiple_patients(variable):
    if 'datetime' not in filtered_data.columns or filtered_data['datetime'].isnull().all() or filtered_data.empty:
        return None

    color_sequence = px.colors.qualitative.Set2
    if plot_type == "line":
        fig = px.line(
            filtered_data,
            x='datetime',
            y=variable,
            color='patient_id',
            title=f"{variable} Over Time Across Selected Patients",
            color_discrete_sequence=color_sequence
        )
    elif plot_type == "scatter":
        fig = px.scatter(
            filtered_data,
            x='datetime',
            y=variable,
            color='patient_id',
            title=f"{variable} Over Time Across Selected Patients",
            color_discrete_sequence=color_sequence
        )
    else:  # bar plot
        fig = px.bar(
            filtered_data,
            x='datetime',
            y=variable,
            color='patient_id',
            title=f"{variable} Over Time Across Selected Patients",
            color_discrete_sequence=color_sequence
        )

    fig.update_layout(
        margin=dict(l=40, r=40, t=80, b=40),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        title={"x": 0.5, "y": 0.95, "xanchor": "center", "yanchor": "top", "font": {"size": 20}}
    )
    fig.update_xaxes(title="Date/Time")
    fig.update_yaxes(title="Measurement Value")

    # If the chosen variable is CRS, add annotations
    if variable == 'CRS on date (0 No, 1 Yes)':
        add_crs_annotations_and_points(fig, filtered_data)

    return fig

if selected_patients and selected_variables:
    if compare_mode == "Compare Multiple Variables per Patient":
        # Generate a plot for each patient in parallel
        with ThreadPoolExecutor() as executor:
            results = list(executor.map(generate_plot_multiple_vars_one_patient, selected_patients))
        for patient_id, result in zip(selected_patients, results):
            if result:
                st.plotly_chart(result, use_container_width=True)
            else:
                st.warning(f"No valid numeric or datetime data available for plotting for Patient {patient_id}.")
    else:
        fig = generate_plot_one_var_multiple_patients(selected_variables[0])
        if fig:
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("No valid numeric or datetime data available for plotting.")
else:
    st.write("No patients or variables selected. Please select options from the sidebar.")